"use client";
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useRouter } from 'next/navigation';
import { Save, ArrowLeft, Loader2 } from 'lucide-react';
import Link from 'next/link';

export default function NewJob() {
  const router = useRouter();
  const [clients, setClients] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [formData, setFormData] = useState({ 
    client_id: "", 
    item_name: "", 
    serial_no: "", 
    problem: "", 
    labour_charges: "0" 
  });

  useEffect(() => {
    // Mobile detection logic
    const checkSize = () => setIsMobile(window.innerWidth < 768);
    checkSize();
    window.addEventListener('resize', checkSize);
    
    supabase.from('clients').select('*').then(({ data }) => setClients(data || []));
    
    return () => window.removeEventListener('resize', checkSize);
  }, []);

  const handleSave = async () => {
    if (!formData.client_id || !formData.item_name) {
      alert("Please select a customer and item name");
      return;
    }
    setLoading(true);
    const { error } = await supabase.from('jobs').insert([{
      ...formData,
      client_id: parseInt(formData.client_id),
      final_bill: parseInt(formData.labour_charges)
    }]);
    if (!error) router.push('/jobs');
    else { alert(error.message); setLoading(false); }
  };

  return (
    <div style={pageContainer}>
      <div style={headerNav}>
        <Link href="/jobs" style={backBtn}><ArrowLeft size={18}/> Back</Link>
      </div>

      <div style={formCard}>
        <h3 style={titleStyle}>New Job Card</h3>
        
        {/* --- Responsive Grid --- */}
        <div style={{ 
          display: 'grid', 
          // PC par 2 columns, Mobile par 1 column (ek ke niche ek)
          gridTemplateColumns: isMobile ? '1fr' : '1fr 1fr', 
          gap: '20px',
          marginTop: '20px' 
        }}>
          
          <div style={inputGroup}>
  <label style={labelStyle}>Select Customer (Type to Search)</label>
  <input
    list="client-list"
    placeholder="Type customer name..."
    style={inputStyle}
    onChange={(e) => {
      // Naam se ID nikalne ka logic
      const selectedClient = clients.find(c => c.name === e.target.value);
      if (selectedClient) {
        setFormData({ ...formData, client_id: selectedClient.id.toString() });
      }
    }}
  />
  <datalist id="client-list">
    {clients.map((c) => (
      <option key={c.id} value={c.name} />
    ))}
  </datalist>
</div>

          <div style={inputGroup}>
            <label style={labelStyle}>Item/Model Name</label>
            <input placeholder="Vivo Y20, iPhone etc." style={inputStyle} onChange={(e) => setFormData({ ...formData, item_name: e.target.value })} />
          </div>

          <div style={inputGroup}>
            <label style={labelStyle}>Serial/IMEI No</label>
            <input placeholder="IMEI or Serial" style={inputStyle} onChange={(e) => setFormData({ ...formData, serial_no: e.target.value })} />
          </div>

          <div style={inputGroup}>
            <label style={labelStyle}>Labour Charges (₹)</label>
            <input type="number" style={inputStyle} onChange={(e) => setFormData({ ...formData, labour_charges: e.target.value })} />
          </div>

          {/* Problem Field - PC par bhi full width rakha hai kyunki ye bada text hota hai */}
          <div style={{ ...inputGroup, gridColumn: isMobile ? '1' : '1 / span 2' }}>
            <label style={labelStyle}>Problem Description</label>
            <textarea placeholder="Describe the issue..." style={textareaStyle} onChange={(e) => setFormData({ ...formData, problem: e.target.value })} />
          </div>
        </div>

        <button onClick={handleSave} disabled={loading} style={{ ...btnSuccess, marginTop: '30px' }}>
          {loading ? <Loader2 className="animate-spin" /> : <Save size={20} />}
          {loading ? 'Saving...' : 'Save Job Card'}
        </button>
      </div>
    </div>
  );
}

// --- Styles ---
const pageContainer: React.CSSProperties = { maxWidth: '800px', margin: '0 auto', padding: '15px' };
const headerNav: React.CSSProperties = { marginBottom: '15px' };
const backBtn: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: '5px', textDecoration: 'none', color: '#666', fontWeight: 'bold' };
const formCard: React.CSSProperties = { background: 'white', padding: '25px', borderRadius: '15px', boxShadow: '0 4px 20px rgba(0,0,0,0.08)' };
const titleStyle: React.CSSProperties = { margin: 0, fontSize: '20px', color: '#333' };
const inputGroup: React.CSSProperties = { display: 'flex', flexDirection: 'column', gap: '8px' };
const labelStyle: React.CSSProperties = { fontSize: '14px', fontWeight: 'bold', color: '#555' };
const inputStyle: React.CSSProperties = { width: '100%', padding: '12px', borderRadius: '8px', border: '1px solid #ddd', backgroundColor: '#fdfdfd', fontSize: '16px', boxSizing: 'border-box' };
const textareaStyle: React.CSSProperties = { ...inputStyle, height: '100px', resize: 'none' };
const btnSuccess: React.CSSProperties = { width: '100%', background: '#28a745', color: 'white', padding: '15px', border: 'none', borderRadius: '10px', cursor: 'pointer', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px', fontSize: '16px', fontWeight: 'bold' };